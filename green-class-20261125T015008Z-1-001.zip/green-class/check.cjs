const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const context = vm.createContext({ document:{}, localStorage:{getItem:()=>null}, Date, Set });
vm.runInContext(fs.readFileSync(__dirname+'/dist/app.js','utf8').split('function render()')[0], context);
const run = code => vm.runInContext(code, context);
assert.equal(run('calculate().points'),0);
run(`state.records = [
  {id:'1',action:'cup',day:'2026-11-21',created:1,status:'approved'},
  {id:'2',action:'cup',day:'2026-11-21',created:2,status:'approved'},
  {id:'3',action:'reuse',day:'2026-11-22',created:3,status:'approved'},
  {id:'4',action:'recycle',day:'2026-11-23',created:4,status:'approved'},
  {id:'5',action:'reuse',day:'2026-11-23',created:5,status:'pending'}
]`);
// One daily cup bonus and one three-day streak bonus; pending proof earns nothing.
assert.equal(run('calculate().points'),110);
assert.equal(run('calculate().entries.length'),4);
run("state.records[2].status='reported'");
// Reporting the middle day removes both its points and the broken streak bonus.
assert.equal(run('calculate().points'),60);
run("state.records[2].status='approved'");
assert.equal(run('calculate().points'),110);
console.log('PASS: approval, daily bonus, streak bonus, report and reapproval');
